import React from "react";
import { Toolbar } from "@material-ui/core";

const Topbar = () => {
  return (
    <Toolbar>
      <h2>Recruiting DataLake</h2>
    </Toolbar>
  );
};

export default Topbar;
